import React from 'react'

const Store = () => {
  return (
    <div>
      <h1>Store</h1>
    </div>
  )
}

export default Store;
