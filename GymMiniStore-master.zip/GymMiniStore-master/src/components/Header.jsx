import React from 'react';
import '../App.css';
import '../index.css';

const Header = () => {
  return (
    <div id='main'>
       <div className='pr-heading'>
       <h1 className='mt-200 text-xxl'>CHANGE</h1>
        <h2 className='mt-200'><span>YOUR LIFESTYLE</span></h2>
       </div>
    </div>
  )
}

export default Header;
